$(function() {
	$("body").noisy({
		monochrome: true,
		opacity: .06,
		intensity: 10
	});
}());
