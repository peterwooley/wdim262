// In js/index.js
alert("Hello from an external file!");
